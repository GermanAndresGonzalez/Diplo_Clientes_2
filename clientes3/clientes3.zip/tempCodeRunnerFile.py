        # self.observador_app = observador.ConcreteObserverA(self.objeto_vista.objeto_acciones)
        # self.observador = Observer.ConcreteObserverA(self.objeto_vista.objeto_acciones)